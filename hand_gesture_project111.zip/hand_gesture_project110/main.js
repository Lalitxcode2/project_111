
var prediction_1 = "";
var prediction_2 = "";

Webcam.set({
    width:350,
    height:300,
    image_format : 'png',
    png_quality:90
});

webcam = document.getElementById("webcam");

Webcam.attach('#webcam');

function snapshot(){
    Webcam.snap(function(selfie) {
        document.getElementById("snap").innerHTML = '<img id="captured_img" src="'+selfie+'">';
    });
}

console.log('ml5 version:',ml5.version);

classifier = ml5.imageClassifier('https://teachablemachine.withgoogle.com/models/z3uwqgCf6/model.json',model_loaded);

function model_loaded(){
    console.log('Model Loaded'); 
}
